Part 1: The main reason for my markup is that I did not want my eyes to bleed when I looked at my webpage -a also it kinda looks like what you had up on the display so I figured it would make part 3 easier if I did something at least close to what you had. I did make the album are a little big (300px) because I feel like that is one of the most important parts of a new album - besides the music. 
My HTML is semantically correct becauseI use the elements properly - and my class/id names describe what that elemt is.

Part 2: I chose this markup because it was the easiest to just use the classes I used in the HTML to name the tags for my XML becasue being creative is hard and my classes are semantically correct.

Part 3: I used the markup I used becasue you told me to format it that way... not sure what else there is to say.

Part 4: Yeah I ran into a lot of trouble with this one - so it is not complete but here is what I have.
