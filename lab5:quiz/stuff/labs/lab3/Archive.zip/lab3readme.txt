part1:

I mostly copied the code you gave us because I was not sure where to start and after looking at what you did I could not think of a different way to do it.

For explinations on how the code works just check the comments

part2: 

this was pretty simple I added on click alert before returning the elemnt so that as each function finished the last thing it would do would be to add the listener before passing up the chain of recursion.

part3:

I was not able to finish this part due to time constraints. I have commented what I have and I feel like I was going in the right direction and given an hour or two more I would be able to get it. 