
//part 1
start = document.getElementsByTagName('html')[0];

var items = part1(start);
document.getElementById('info').innerHTML = items;


function part1 (me, depth){
	//sets the depth counter
	if (!depth){
		depth=0;
	}
	//if it is a node
	if (me.nodeType == 1){
		var text = '';
		//use depth to add "-"
		for (var i = 0; i < depth; i++) {
			text += "-";
		}
		//get the current tagname
		text += me.tagName + "\n";
		//call the function again all of the current child nodes
		for (var n = 0; n < me.childNodes.length; n++) {
			childTxt = part1(me.childNodes[n], depth+1);
			//add the list returnd by the function to the text list to be passed up the recursive chain
			if(childTxt != null && childTxt != ''){
				text += childTxt;
			}
		}
		//this is for part 2
		//when the function hits an element it also adds an onclick function
		//this function makes an alert that has the current tag
		me.onclick = function(){
				alert("Current tag: " + this.tagName);
		}
	return text;
}
else {
	return null;
}

}


window.onload = function(){
	//get all the divs
	var theDivas = document.getElementsByTagName("div"); 
	//get a div ready to add to the doc
	var quote = document.createElement('div');
	//clone a p from one of the divs and add it to the div
	quote.appendChild(theDivas[0].getElementsByTagName("p")[0].cloneNode(true));
	//add that div to the document (not working)
	//document.getElementsByTagName("body").appendChild(quote);

	//would go through the list of divs and add the mousover css to change the background color
	//and move it 10 px
	for (var i = 0; i >= theDivas.length; i++) {
		theDivas[i].onmouseover = function(){
			this.css("color", "pink");
		}
	};

}