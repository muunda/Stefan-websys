part 1:
The JSON is set up as a list called "songs" and each element is a song containing all the information about each song.

part 2:
I loop through the songs building up a string containing each song - then append it to the DOM.
You can see that it works properly becasue it uses the sam CSS as lab 2 without any modifications.

github: https://github.com/muunda/Stefan-websys